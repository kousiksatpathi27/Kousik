/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { BlogFeed } from './components/BlogFeed';
import { AboutSection } from './components/AboutSection';
import { CategoriesSection } from './components/CategoriesSection';
import { ConnectSection } from './components/ConnectSection';
import { Footer } from './components/Footer';
import { CreatePostModal } from './components/CreatePostModal';
import { PostReaderModal } from './components/PostReaderModal';
import { 
  authorProfile, 
  getStoredPosts, 
  saveStoredPosts 
} from './data/blogData';
import { BlogPost } from './types/blog';
import { CheckCircle2, Sparkles, X } from 'lucide-react';

export default function App() {
  const [posts, setPosts] = useState<BlogPost[]>(() => getStoredPosts());
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeSection, setActiveSection] = useState<string>('home');
  const [isDarkMode, setIsDarkMode] = useState<boolean>(() => {
    return window.matchMedia?.('(prefers-color-scheme: dark)').matches || false;
  });

  // Modals state
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [editingPost, setEditingPost] = useState<BlogPost | null>(null);
  const [readingPost, setReadingPost] = useState<BlogPost | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Sync dark mode class
  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Persist posts whenever modified
  const updatePostsAndStorage = (updater: (prev: BlogPost[]) => BlogPost[]) => {
    setPosts((prev) => {
      const next = updater(prev);
      saveStoredPosts(next);
      return next;
    });
  };

  // Toast handler
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 4500);
  };

  // Handlers
  const handleSavePost = (savedPost: BlogPost) => {
    updatePostsAndStorage((prev) => {
      const existsIndex = prev.findIndex((p) => p.id === savedPost.id);
      if (existsIndex >= 0) {
        // Editing existing post
        const next = [...prev];
        next[existsIndex] = savedPost;
        showToast('Story updated successfully! Changes are live on your Home page.');
        return next;
      } else {
        // Newly created post - prepends to the top so it immediately appears on the Home page!
        showToast('🎉 New story published! It is now live on your Home page feed.');
        return [savedPost, ...prev];
      }
    });

    // If reading the post being edited, update reader too
    if (readingPost && readingPost.id === savedPost.id) {
      setReadingPost(savedPost);
    }

    // Scroll to feed to see the newly published post
    scrollToSection('posts');
  };

  const handleDeletePost = (postId: string) => {
    updatePostsAndStorage((prev) => prev.filter((p) => p.id !== postId));
    showToast('Post deleted successfully.');
    if (readingPost?.id === postId) {
      setReadingPost(null);
    }
  };

  const handleLikePost = (postId: string) => {
    updatePostsAndStorage((prev) =>
      prev.map((p) => (p.id === postId ? { ...p, likes: p.likes + 1 } : p))
    );
    if (readingPost && readingPost.id === postId) {
      setReadingPost((prev) => prev ? { ...prev, likes: prev.likes + 1 } : null);
    }
  };

  const handleAddComment = (postId: string, authorName: string, content: string) => {
    const newComment = {
      id: `comment-${Date.now()}`,
      author: authorName,
      content,
      createdAt: new Date().toISOString().replace('T', ' ').slice(0, 16),
    };

    updatePostsAndStorage((prev) =>
      prev.map((p) =>
        p.id === postId
          ? { ...p, comments: [newComment, ...p.comments] }
          : p
      )
    );

    if (readingPost && readingPost.id === postId) {
      setReadingPost((prev) =>
        prev
          ? { ...prev, comments: [newComment, ...prev.comments] }
          : null
      );
    }

    showToast('Your comment was posted!');
  };

  const handleReadPost = (post: BlogPost) => {
    // Increment view count
    updatePostsAndStorage((prev) =>
      prev.map((p) => (p.id === post.id ? { ...p, views: p.views + 1 } : p))
    );
    setReadingPost({ ...post, views: post.views + 1 });
  };

  const handleOpenEdit = (post: BlogPost) => {
    setEditingPost(post);
    setIsCreateModalOpen(true);
  };

  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    if (sectionId === 'home') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const elem = document.getElementById(sectionId);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleCategorySelect = (categoryName: string) => {
    setSelectedCategory(categoryName);
    scrollToSection('posts');
  };

  const getPostCountByCategory = (catName: string) => {
    return posts.filter((p) => p.category === catName).length;
  };

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 dark:bg-stone-950 dark:text-stone-100 flex flex-col font-sans transition-colors duration-200">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 flex items-center gap-2.5 rounded-xl border border-emerald-500/30 bg-emerald-900/90 text-white px-4 py-3 shadow-xl backdrop-blur-md animate-fade-in text-xs sm:text-sm font-medium">
          <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
          <button
            onClick={() => setToastMessage(null)}
            className="ml-2 text-stone-300 hover:text-white"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      {/* Navigation */}
      <Navbar
        onOpenCreateModal={() => {
          setEditingPost(null);
          setIsCreateModalOpen(true);
        }}
        activeSection={activeSection}
        onNavigate={scrollToSection}
        isDarkMode={isDarkMode}
        onToggleTheme={() => setIsDarkMode(!isDarkMode)}
        postCount={posts.length}
      />

      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          author={authorProfile}
          totalPosts={posts.length}
          onOpenCreateModal={() => {
            setEditingPost(null);
            setIsCreateModalOpen(true);
          }}
          onScrollToPosts={() => scrollToSection('posts')}
          onSelectCategory={handleCategorySelect}
        />

        {/* Live Blog Post Feed (Answers: "R ami ja post korbo show kore jemon Home page eii") */}
        <BlogFeed
          posts={posts}
          selectedCategory={selectedCategory}
          onSelectCategory={setSelectedCategory}
          onReadPost={handleReadPost}
          onOpenCreateModal={() => {
            setEditingPost(null);
            setIsCreateModalOpen(true);
          }}
          onLikePost={handleLikePost}
          onEditPost={handleOpenEdit}
          onDeletePost={handleDeletePost}
        />

        {/* What I Write About / 4 Core Niches Showcase */}
        <CategoriesSection
          categories={authorProfile.categories}
          onSelectCategory={handleCategorySelect}
          getPostCountByCategory={getPostCountByCategory}
        />

        {/* About Me & Philosophy Section */}
        <AboutSection
          author={authorProfile}
          onOpenCreateModal={() => {
            setEditingPost(null);
            setIsCreateModalOpen(true);
          }}
        />

        {/* Connect & Contact Section */}
        <ConnectSection author={authorProfile} />
      </main>

      {/* Footer */}
      <Footer author={authorProfile} onNavigate={scrollToSection} />

      {/* Create / Edit Post Modal */}
      <CreatePostModal
        isOpen={isCreateModalOpen}
        onClose={() => {
          setIsCreateModalOpen(false);
          setEditingPost(null);
        }}
        onSavePost={handleSavePost}
        initialPost={editingPost}
      />

      {/* Post Reading & Comments Modal */}
      <PostReaderModal
        post={readingPost}
        onClose={() => setReadingPost(null)}
        onLike={handleLikePost}
        onAddComment={handleAddComment}
        onEdit={handleOpenEdit}
        onDelete={handleDeletePost}
      />

    </div>
  );
}
