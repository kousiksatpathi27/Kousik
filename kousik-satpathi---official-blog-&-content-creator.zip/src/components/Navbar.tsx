import React, { useState } from 'react';
import { 
  PenTool, 
  Compass, 
  User, 
  MessageSquare, 
  Menu, 
  X, 
  Sun, 
  Moon, 
  Globe,
  Sparkles
} from 'lucide-react';

interface NavbarProps {
  onOpenCreateModal: () => void;
  activeSection: string;
  onNavigate: (sectionId: string) => void;
  isDarkMode: boolean;
  onToggleTheme: () => void;
  postCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  onOpenCreateModal,
  activeSection,
  onNavigate,
  isDarkMode,
  onToggleTheme,
  postCount,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'posts', label: 'Articles', count: postCount },
    { id: 'categories', label: 'Topics' },
    { id: 'about', label: 'About Me' },
    { id: 'connect', label: 'Connect' },
  ];

  const handleNavClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-stone-200/80 bg-stone-50/90 backdrop-blur-md transition-colors dark:border-stone-800 dark:bg-stone-950/90">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8 h-18">
        {/* Brand identity */}
        <button
          onClick={() => handleNavClick('home')}
          className="group flex items-center gap-3 text-left focus:outline-none"
        >
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-stone-900 text-stone-100 font-serif font-bold text-xl shadow-sm transition-transform group-hover:scale-105 dark:bg-stone-100 dark:text-stone-900">
            K
          </div>
          <div className="flex flex-col">
            <span className="font-serif text-lg font-bold tracking-tight text-stone-900 dark:text-stone-100 group-hover:text-amber-700 dark:group-hover:text-amber-400 transition-colors">
              Kousik Satpathi
            </span>
            <span className="text-[11px] font-medium tracking-wide text-stone-500 uppercase dark:text-stone-400">
              Blogger & Content Creator
            </span>
          </div>
        </button>

        {/* Desktop Navigation Links */}
        <nav className="hidden md:flex items-center gap-1 lg:gap-2">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`relative px-3.5 py-2 text-sm font-medium transition-colors ${
                activeSection === item.id
                  ? 'text-amber-700 font-semibold dark:text-amber-400'
                  : 'text-stone-600 hover:text-stone-900 dark:text-stone-300 dark:hover:text-stone-100'
              }`}
            >
              {item.label}
              {item.count !== undefined && (
                <span className="ml-1.5 text-xs text-stone-400 dark:text-stone-500 font-mono">
                  ({item.count})
                </span>
              )}
              {activeSection === item.id && (
                <span className="absolute bottom-0 left-3.5 right-3.5 h-0.5 bg-amber-600 dark:bg-amber-400" />
              )}
            </button>
          ))}
          <a
            href="https://www.kousiksatpathi.blogspot.com"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center gap-1 px-3 py-2 text-xs font-medium text-stone-500 hover:text-stone-900 dark:text-stone-400 dark:hover:text-stone-200 transition-colors"
            title="Visit original Blogspot"
          >
            <Globe className="h-3.5 w-3.5" />
            <span>Blogspot</span>
          </a>
        </nav>

        {/* Action Controls */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Theme Toggle */}
          <button
            onClick={onToggleTheme}
            aria-label="Toggle color theme"
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-stone-200 bg-white text-stone-600 transition-colors hover:bg-stone-100 hover:text-stone-900 dark:border-stone-800 dark:bg-stone-900 dark:text-stone-300 dark:hover:bg-stone-800 dark:hover:text-white"
          >
            {isDarkMode ? <Sun className="h-4 w-4 text-amber-400" /> : <Moon className="h-4 w-4" />}
          </button>

          {/* Create Post Button (Requested: ami ja post korbo show kore) */}
          <button
            onClick={onOpenCreateModal}
            className="group flex items-center gap-2 rounded-lg bg-amber-600 px-3.5 py-2 text-xs sm:text-sm font-semibold text-white shadow-sm transition-all hover:bg-amber-700 hover:shadow active:scale-98 dark:bg-amber-500 dark:hover:bg-amber-600"
          >
            <PenTool className="h-3.5 w-3.5 sm:h-4 sm:w-4 transition-transform group-hover:-rotate-12" />
            <span>New Post</span>
            <span className="hidden lg:inline text-amber-200 text-xs">/ নতুন পোস্ট</span>
          </button>

          {/* Mobile hamburger menu toggle */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="flex h-9 w-9 items-center justify-center rounded-lg border border-stone-200 bg-white text-stone-700 md:hidden dark:border-stone-800 dark:bg-stone-900 dark:text-stone-300"
            aria-label="Toggle mobile menu"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu dropdown */}
      {mobileMenuOpen && (
        <div className="border-b border-stone-200 bg-stone-50 px-4 py-4 md:hidden dark:border-stone-800 dark:bg-stone-950 animate-fade-in">
          <div className="flex flex-col space-y-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`flex items-center justify-between rounded-lg px-3 py-2 text-left text-sm font-medium ${
                  activeSection === item.id
                    ? 'bg-amber-100 text-amber-900 dark:bg-amber-950/60 dark:text-amber-300'
                    : 'text-stone-700 hover:bg-stone-100 dark:text-stone-300 dark:hover:bg-stone-900'
                }`}
              >
                <span>{item.label}</span>
                {item.count !== undefined && (
                  <span className="text-xs text-stone-400 font-mono">
                    {item.count} articles
                  </span>
                )}
              </button>
            ))}
            <a
              href="https://www.kousiksatpathi.blogspot.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-stone-600 hover:bg-stone-100 dark:text-stone-400 dark:hover:bg-stone-900"
            >
              <Globe className="h-4 w-4" />
              <span>Visit Blogspot (Original)</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};
