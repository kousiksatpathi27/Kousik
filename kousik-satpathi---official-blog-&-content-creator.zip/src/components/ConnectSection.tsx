import React, { useState } from 'react';
import { 
  Mail, 
  Send, 
  Globe, 
  CheckCircle, 
  Sparkles, 
  MessageCircle,
  ExternalLink
} from 'lucide-react';
import { AuthorProfile } from '../types/blog';

interface ConnectSectionProps {
  author: AuthorProfile;
}

export const ConnectSection: React.FC<ConnectSectionProps> = ({ author }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !message.trim()) return;

    // Save message locally
    try {
      const existing = JSON.parse(localStorage.getItem('kousik_contact_messages') || '[]');
      existing.push({
        id: Date.now(),
        name,
        email,
        message,
        date: new Date().toISOString(),
      });
      localStorage.setItem('kousik_contact_messages', JSON.stringify(existing));
    } catch (e) {
      console.error(e);
    }

    setSubmitted(true);
    setTimeout(() => {
      setSubmitted(false);
      setName('');
      setEmail('');
      setMessage('');
    }, 4000);
  };

  return (
    <section id="connect" className="py-20 border-t border-stone-200/80 bg-stone-100/50 dark:border-stone-800 dark:bg-stone-900/40">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Column: Direct Links & Bio Warmth */}
          <div className="lg:col-span-5 space-y-6">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
                Get In Touch
              </span>
              <h2 className="font-serif text-3xl sm:text-4xl font-bold tracking-tight text-stone-900 dark:text-stone-100 mt-1">
                Connect With Me
              </h2>
              <p className="text-stone-600 dark:text-stone-300 mt-3 text-base leading-relaxed">
                I’d love to connect with you and hear your thoughts, feedback, travel recommendations, or collaboration ideas.
              </p>
            </div>

            {/* Social Connection Cards */}
            <div className="space-y-3">
              
              {/* Facebook */}
              <a
                href={author.socials.facebook}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between rounded-xl border border-stone-200 bg-white p-4 text-stone-800 hover:border-blue-500 hover:shadow-sm dark:border-stone-800 dark:bg-stone-900 dark:text-stone-200 transition-all group"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-blue-50 text-blue-600 dark:bg-blue-950/60 dark:text-blue-400 font-bold text-sm">
                    f
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-stone-400 uppercase">Facebook</p>
                    <p className="text-sm font-bold text-stone-900 dark:text-stone-100 group-hover:text-blue-600">
                      facebook.com/kousiksatpathi
                    </p>
                  </div>
                </div>
                <ExternalLink className="h-4 w-4 text-stone-400 group-hover:text-blue-600" />
              </a>

              {/* Instagram */}
              <a
                href={author.socials.instagram}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between rounded-xl border border-stone-200 bg-white p-4 text-stone-800 hover:border-pink-500 hover:shadow-sm dark:border-stone-800 dark:bg-stone-900 dark:text-stone-200 transition-all group"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-pink-50 text-pink-600 dark:bg-pink-950/60 dark:text-pink-400 font-bold text-sm">
                    ig
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-stone-400 uppercase">Instagram</p>
                    <p className="text-sm font-bold text-stone-900 dark:text-stone-100 group-hover:text-pink-600">
                      @kousiksatpathi
                    </p>
                  </div>
                </div>
                <ExternalLink className="h-4 w-4 text-stone-400 group-hover:text-pink-600" />
              </a>

              {/* Official Blogspot */}
              <a
                href={author.socials.blogspot}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center justify-between rounded-xl border border-stone-200 bg-white p-4 text-stone-800 hover:border-amber-500 hover:shadow-sm dark:border-stone-800 dark:bg-stone-900 dark:text-stone-200 transition-all group"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-50 text-amber-700 dark:bg-amber-950/60 dark:text-amber-400">
                    <Globe className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-stone-400 uppercase">Original Blog</p>
                    <p className="text-sm font-bold text-stone-900 dark:text-stone-100 group-hover:text-amber-600">
                      kousiksatpathi.blogspot.com
                    </p>
                  </div>
                </div>
                <ExternalLink className="h-4 w-4 text-stone-400 group-hover:text-amber-600" />
              </a>

              {/* Email */}
              <a
                href={`mailto:${author.socials.email}`}
                className="flex items-center justify-between rounded-xl border border-stone-200 bg-white p-4 text-stone-800 hover:border-amber-500 hover:shadow-sm dark:border-stone-800 dark:bg-stone-900 dark:text-stone-200 transition-all group"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-stone-100 text-stone-700 dark:bg-stone-800 dark:text-stone-300">
                    <Mail className="h-5 w-5" />
                  </div>
                  <div>
                    <p className="text-xs font-semibold text-stone-400 uppercase">Direct Email</p>
                    <p className="text-sm font-bold text-stone-900 dark:text-stone-100 group-hover:text-amber-600">
                      {author.socials.email}
                    </p>
                  </div>
                </div>
                <ExternalLink className="h-4 w-4 text-stone-400 group-hover:text-amber-600" />
              </a>

            </div>

            <div className="rounded-xl border border-stone-200 bg-white/80 p-4 dark:border-stone-800 dark:bg-stone-900/60 text-xs text-stone-500 dark:text-stone-400">
              <p className="font-semibold text-stone-800 dark:text-stone-200 mb-1">
                Thank you for visiting my blog and being a part of my journey.
              </p>
              <p className="font-serif italic text-amber-700 dark:text-amber-400">
                {author.motto}
              </p>
            </div>
          </div>

          {/* Right Column: Direct Message Form */}
          <div className="lg:col-span-7">
            <div className="rounded-2xl border border-stone-200 bg-white p-6 sm:p-8 shadow-sm dark:border-stone-800 dark:bg-stone-900">
              <div className="flex items-center gap-2 mb-2">
                <MessageCircle className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                <h3 className="font-serif text-2xl font-bold text-stone-900 dark:text-stone-100">
                  Send Kousik a Message
                </h3>
              </div>
              <p className="text-xs text-stone-500 dark:text-stone-400 mb-6">
                Have a question about a ride, want tech advice, or just want to say hi from Bengal? Drop a line below!
              </p>

              {submitted ? (
                <div className="rounded-xl bg-emerald-50 border border-emerald-200 p-6 text-center dark:bg-emerald-950/40 dark:border-emerald-800 animate-fade-in">
                  <CheckCircle className="h-8 w-8 text-emerald-600 dark:text-emerald-400 mx-auto mb-2" />
                  <p className="font-serif text-lg font-bold text-emerald-900 dark:text-emerald-200">
                    Thank you! Your message has been sent.
                  </p>
                  <p className="text-xs text-emerald-700 dark:text-emerald-300 mt-1">
                    Kousik will get back to you soon.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1">
                        Your Name *
                      </label>
                      <input
                        type="text"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="e.g. Joydeep Banerjee"
                        required
                        className="w-full rounded-lg border border-stone-300 px-3.5 py-2 text-sm text-stone-900 placeholder-stone-400 focus:border-amber-500 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1">
                        Your Email *
                      </label>
                      <input
                        type="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        placeholder="yourname@gmail.com"
                        required
                        className="w-full rounded-lg border border-stone-300 px-3.5 py-2 text-sm text-stone-900 placeholder-stone-400 focus:border-amber-500 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1">
                      Message *
                    </label>
                    <textarea
                      rows={4}
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      placeholder="Hi Kousik, I enjoyed your travel post on Mukutmanipur..."
                      required
                      className="w-full rounded-lg border border-stone-300 px-3.5 py-2.5 text-sm text-stone-900 placeholder-stone-400 focus:border-amber-500 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
                    />
                  </div>

                  <div className="flex justify-end pt-2">
                    <button
                      type="submit"
                      className="inline-flex items-center gap-2 rounded-lg bg-amber-600 px-5 py-2.5 text-sm font-semibold text-white shadow-xs hover:bg-amber-700 active:scale-98 transition-all dark:bg-amber-500 dark:hover:bg-amber-600"
                    >
                      <Send className="h-4 w-4" />
                      <span>Send Message</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>

        </div>

      </div>
    </section>
  );
};
