import React from 'react';
import { ArrowUp, Globe, Heart, MapPin } from 'lucide-react';
import { AuthorProfile } from '../types/blog';

interface FooterProps {
  author: AuthorProfile;
  onNavigate: (sectionId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ author, onNavigate }) => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="border-t border-stone-200 bg-white py-12 dark:border-stone-800 dark:bg-stone-950 transition-colors">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10 pb-10 border-b border-stone-100 dark:border-stone-800">
          
          {/* Brand Info */}
          <div className="md:col-span-2 space-y-3">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-stone-900 text-stone-100 font-serif font-bold text-base dark:bg-stone-100 dark:text-stone-900">
                K
              </div>
              <span className="font-serif text-lg font-bold text-stone-900 dark:text-stone-100">
                {author.name}
              </span>
            </div>
            
            <p className="text-xs sm:text-sm text-stone-500 dark:text-stone-400 max-w-md leading-relaxed">
              Personal blog and creative space documenting travel expeditions, digital technology, photography, and lessons learned from everyday life in Simlapal, Bankura.
            </p>

            <div className="flex items-center gap-1.5 text-xs text-amber-700 dark:text-amber-400 font-medium">
              <MapPin className="h-3.5 w-3.5" />
              <span>Simlapal, Bankura, West Bengal, India</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-2">
            <p className="text-xs font-bold uppercase tracking-wider text-stone-900 dark:text-stone-100">
              Navigation
            </p>
            <ul className="space-y-1.5 text-xs text-stone-600 dark:text-stone-400">
              <li>
                <button onClick={() => onNavigate('home')} className="hover:text-amber-600 transition-colors">
                  Home
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('posts')} className="hover:text-amber-600 transition-colors">
                  All Articles
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('categories')} className="hover:text-amber-600 transition-colors">
                  Topics
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-amber-600 transition-colors">
                  About Me
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('connect')} className="hover:text-amber-600 transition-colors">
                  Connect & Contact
                </button>
              </li>
            </ul>
          </div>

          {/* Social Presence */}
          <div className="space-y-2">
            <p className="text-xs font-bold uppercase tracking-wider text-stone-900 dark:text-stone-100">
              Channels
            </p>
            <ul className="space-y-1.5 text-xs text-stone-600 dark:text-stone-400">
              <li>
                <a
                  href={author.socials.facebook}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-blue-600 transition-colors"
                >
                  Facebook / kousiksatpathi
                </a>
              </li>
              <li>
                <a
                  href={author.socials.instagram}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-pink-600 transition-colors"
                >
                  Instagram @kousiksatpathi
                </a>
              </li>
              <li>
                <a
                  href={author.socials.blogspot}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-amber-600 transition-colors"
                >
                  kousiksatpathi.blogspot.com
                </a>
              </li>
              <li>
                <a
                  href={`mailto:${author.socials.email}`}
                  className="hover:text-amber-600 transition-colors"
                >
                  {author.socials.email}
                </a>
              </li>
            </ul>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500 dark:text-stone-400">
          <p>
            © {new Date().getFullYear()} {author.name}. All rights reserved. •{' '}
            <span className="font-serif italic text-stone-700 dark:text-stone-300">
              {author.motto}
            </span>
          </p>

          <button
            onClick={scrollToTop}
            className="flex items-center gap-1.5 rounded-lg border border-stone-200 px-3 py-1.5 hover:bg-stone-50 dark:border-stone-800 dark:hover:bg-stone-900 text-stone-600 dark:text-stone-300 transition-colors"
          >
            <span>Back to top</span>
            <ArrowUp className="h-3.5 w-3.5" />
          </button>
        </div>

      </div>
    </footer>
  );
};
