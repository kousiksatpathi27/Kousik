import React from 'react';
import { 
  Plane, 
  Laptop, 
  Camera, 
  BookOpen, 
  Coffee, 
  Music, 
  Quote, 
  Sparkles, 
  MapPin, 
  ArrowUpRight 
} from 'lucide-react';
import { AuthorProfile } from '../types/blog';

interface AboutSectionProps {
  author: AuthorProfile;
  onOpenCreateModal: () => void;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ author, onOpenCreateModal }) => {
  // Map icon strings to Lucide components
  const getInterestIcon = (iconName: string) => {
    switch (iconName) {
      case 'Plane': return <Plane className="h-5 w-5 text-amber-600 dark:text-amber-400" />;
      case 'Laptop': return <Laptop className="h-5 w-5 text-blue-600 dark:text-blue-400" />;
      case 'Camera': return <Camera className="h-5 w-5 text-emerald-600 dark:text-emerald-400" />;
      case 'BookOpen': return <BookOpen className="h-5 w-5 text-indigo-600 dark:text-indigo-400" />;
      case 'Coffee': return <Coffee className="h-5 w-5 text-amber-700 dark:text-amber-500" />;
      case 'Music': return <Music className="h-5 w-5 text-purple-600 dark:text-purple-400" />;
      default: return <Sparkles className="h-5 w-5 text-amber-600" />;
    }
  };

  return (
    <section id="about" className="py-20 border-t border-stone-200/80 bg-stone-100/40 dark:border-stone-800 dark:bg-stone-900/30">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="max-w-2xl mb-12">
          <span className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
            Behind the Words
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-stone-900 dark:text-stone-100 mt-1">
            About Kousik Satpathi
          </h2>
          <p className="text-base text-stone-500 dark:text-stone-400 mt-2">
            A small personal journal that turned into an open window to the world.
          </p>
        </div>

        {/* Narrative & Photo Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start mb-16">
          
          {/* Left Column: Portrait & Quick Stats */}
          <div className="lg:col-span-5 flex flex-col space-y-6">
            <div className="relative rounded-2xl overflow-hidden shadow-xl border border-stone-200 dark:border-stone-800 bg-stone-900">
              <img
                src={author.avatarUrl}
                alt="Kousik Satpathi Portrait"
                className="w-full aspect-[4/5] object-cover object-top"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 text-white text-left">
                <p className="font-serif text-xl font-bold">{author.name}</p>
                <div className="flex items-center gap-1.5 text-xs text-stone-300 mt-1">
                  <MapPin className="h-3.5 w-3.5 text-amber-400" />
                  <span>{author.location}</span>
                </div>
              </div>
            </div>

            {/* Favorite Quote Callout */}
            <div className="rounded-xl border border-amber-200 bg-amber-50/80 p-5 dark:border-amber-900/40 dark:bg-amber-950/30">
              <div className="flex items-start gap-3">
                <Quote className="h-6 w-6 text-amber-600 dark:text-amber-400 shrink-0 mt-0.5" />
                <div>
                  <p className="font-serif text-base font-bold italic text-amber-950 dark:text-amber-200 leading-snug">
                    {author.quote}
                  </p>
                  <p className="text-xs text-amber-800/80 dark:text-amber-400/80 mt-2 font-medium">
                    — Kousik’s Guiding Philosophy
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Full Story & Thoughts */}
          <div className="lg:col-span-7 space-y-6">
            <div className="space-y-4 text-stone-700 dark:text-stone-300 text-base sm:text-lg leading-relaxed">
              {author.aboutFull.map((paragraph, idx) => (
                <p key={idx} className={idx === 0 ? 'font-medium text-stone-900 dark:text-stone-100 text-lg' : ''}>
                  {paragraph}
                </p>
              ))}
            </div>

            <div className="pt-4 border-t border-stone-200 dark:border-stone-800">
              <h3 className="font-serif text-xl font-bold text-stone-900 dark:text-stone-100 mb-2">
                Simlapal, Bankura: Where It All Began
              </h3>
              <p className="text-sm text-stone-600 dark:text-stone-400 leading-relaxed">
                Bankura is known for its terracotta heritage, winding red clay trails, and quiet natural serenity. Living in Simlapal gives me a unique vantage point: rooted in cultural depth, yet connected to the rapid pulse of modern technology and the digital creator economy.
              </p>
            </div>

            {/* Motto Badge */}
            <div className="rounded-xl border border-stone-200 bg-white p-5 dark:border-stone-800 dark:bg-stone-900 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-stone-400">
                  Creator Motto
                </span>
                <p className="font-serif text-lg font-bold text-stone-900 dark:text-stone-100">
                  {author.motto}
                </p>
              </div>

              <a
                href={author.socials.blogspot}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-xs font-semibold text-amber-700 hover:text-amber-800 dark:text-amber-400 dark:hover:text-amber-300"
              >
                <span>Visit Blogspot</span>
                <ArrowUpRight className="h-4 w-4" />
              </a>
            </div>

          </div>

        </div>

        {/* My Interests Section */}
        <div id="interests" className="pt-10 border-t border-stone-200 dark:border-stone-800">
          <div className="mb-8">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
              Passions
            </span>
            <h3 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900 dark:text-stone-100">
              My Interests & Daily Inspirations
            </h3>
            <p className="text-xs sm:text-sm text-stone-500 dark:text-stone-400 mt-1">
              What keeps my mind active and creative every single day.
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
            {author.interests.map((interest) => (
              <div
                key={interest.label}
                className="rounded-xl border border-stone-200/90 bg-white p-4 text-center dark:border-stone-800 dark:bg-stone-900/80 shadow-2xs hover:border-amber-500 hover:shadow-md transition-all group"
              >
                <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-xl bg-stone-100 dark:bg-stone-800 mb-3 group-hover:scale-110 transition-transform">
                  {getInterestIcon(interest.icon)}
                </div>
                <h4 className="font-serif text-sm font-bold text-stone-900 dark:text-stone-100">
                  {interest.label}
                </h4>
                <p className="text-[11px] text-stone-500 dark:text-stone-400 mt-1 line-clamp-2 leading-snug">
                  {interest.desc}
                </p>
              </div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
};
