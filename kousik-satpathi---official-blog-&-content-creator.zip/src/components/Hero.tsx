import React, { useState } from 'react';
import { 
  MapPin, 
  PenLine, 
  ArrowDown, 
  Globe, 
  Mail, 
  Share2, 
  Compass, 
  Sparkles,
  BookOpen,
  Quote
} from 'lucide-react';
import { AuthorProfile } from '../types/blog';

interface HeroProps {
  author: AuthorProfile;
  totalPosts: number;
  onOpenCreateModal: () => void;
  onScrollToPosts: () => void;
  onSelectCategory: (category: string) => void;
}

export const Hero: React.FC<HeroProps> = ({
  author,
  totalPosts,
  onOpenCreateModal,
  onScrollToPosts,
  onSelectCategory,
}) => {
  const [activePhoto, setActivePhoto] = useState<'rider' | 'portrait'>('rider');

  const displayImage = activePhoto === 'rider' ? author.coverHeroUrl : author.avatarUrl;

  const topics = [
    { label: 'Lifestyle', icon: '☕' },
    { label: 'Travel', icon: '✈️' },
    { label: 'Technology', icon: '💻' },
    { label: 'Personal Stories', icon: '📖' },
  ];

  return (
    <section className="relative overflow-hidden border-b border-stone-200/80 bg-gradient-to-b from-stone-100/60 via-stone-50 to-stone-100/30 pt-10 pb-16 sm:py-20 dark:border-stone-800 dark:from-stone-900/40 dark:via-stone-950 dark:to-stone-900/20">
      {/* Subtle background decorative pattern */}
      <div className="absolute inset-0 bg-[radial-gradient(#d97706_1px,transparent_1px)] [background-size:24px_24px] opacity-[0.03] dark:opacity-[0.06] pointer-events-none" />

      <div className="relative mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          
          {/* Left Column: Author Narrative & Identity */}
          <div className="lg:col-span-7 flex flex-col space-y-6 text-left">
            
            {/* Location & Status Tag */}
            <div className="flex flex-wrap items-center gap-3">
              <div className="inline-flex items-center gap-1.5 text-xs font-semibold tracking-wide uppercase text-amber-800 dark:text-amber-400">
                <MapPin className="h-3.5 w-3.5 text-amber-600 dark:text-amber-500" />
                <span>{author.location}</span>
              </div>
              <span className="text-stone-300 dark:text-stone-700">|</span>
              <span className="inline-flex items-center gap-1.5 text-xs text-stone-500 dark:text-stone-400 font-medium">
                <span className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
                Creator & Storyteller
              </span>
            </div>

            {/* Main Title & Editorial Headline */}
            <div>
              <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-stone-900 dark:text-stone-100 leading-[1.12]">
                {author.name}
              </h1>
              <p className="mt-3 text-lg sm:text-xl font-medium text-amber-700 dark:text-amber-400">
                {author.tagline}
              </p>
            </div>

            {/* Core Niches Horizontal Strip */}
            <div className="flex flex-wrap gap-2 pt-1">
              {topics.map((t) => (
                <button
                  key={t.label}
                  onClick={() => onSelectCategory(t.label)}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-stone-200/90 bg-white/80 px-3 py-1.5 text-xs font-semibold text-stone-700 shadow-2xs backdrop-blur-xs transition-all hover:border-amber-500 hover:text-amber-700 hover:bg-amber-50/50 dark:border-stone-800 dark:bg-stone-900/80 dark:text-stone-300 dark:hover:border-amber-500 dark:hover:text-amber-400"
                >
                  <span>{t.icon}</span>
                  <span>{t.label}</span>
                </button>
              ))}
            </div>

            {/* Welcome Statement */}
            <div className="space-y-3 text-stone-600 dark:text-stone-300 text-base sm:text-lg leading-relaxed">
              <p className="font-serif italic text-stone-800 dark:text-stone-200 text-lg border-l-2 border-amber-500 pl-4 py-0.5">
                “Welcome to my little corner of the internet. I hope you find something here that informs, inspires, or simply makes your day a little better.”
              </p>
              <p className="text-sm sm:text-base text-stone-600 dark:text-stone-400">
                Hi, I’m Kousik — born and raised in Bankura. I love exploring new places on two wheels, learning about modern technology, capturing moments through photography, and sharing real-life experiences.
              </p>
            </div>

            {/* Primary Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onOpenCreateModal}
                className="inline-flex items-center gap-2 rounded-lg bg-amber-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm transition-all hover:bg-amber-700 hover:shadow-md active:scale-98 dark:bg-amber-500 dark:hover:bg-amber-600"
              >
                <PenLine className="h-4 w-4" />
                <span>Write New Post</span>
                <span className="text-amber-200 text-xs hidden sm:inline">/ নতুন পোস্ট</span>
              </button>

              <button
                onClick={onScrollToPosts}
                className="inline-flex items-center gap-2 rounded-lg border border-stone-300 bg-white px-5 py-2.5 text-sm font-semibold text-stone-800 shadow-2xs transition-all hover:bg-stone-100 hover:border-stone-400 dark:border-stone-700 dark:bg-stone-900 dark:text-stone-200 dark:hover:bg-stone-800"
              >
                <span>Read Articles</span>
                <ArrowDown className="h-4 w-4 text-stone-500" />
              </button>

              <a
                href={author.socials.blogspot}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 rounded-lg px-3.5 py-2 text-xs font-semibold text-stone-600 transition-colors hover:text-stone-900 dark:text-stone-400 dark:hover:text-stone-200"
                title="kousiksatpathi.blogspot.com"
              >
                <Globe className="h-4 w-4 text-amber-600 dark:text-amber-400" />
                <span>kousiksatpathi.blogspot.com</span>
              </a>
            </div>

            {/* Quick Stats Grid */}
            <div className="grid grid-cols-3 gap-4 pt-4 border-t border-stone-200/80 dark:border-stone-800">
              <div>
                <p className="font-serif text-2xl font-bold text-stone-900 dark:text-stone-100">{totalPosts}</p>
                <p className="text-xs text-stone-500 dark:text-stone-400 font-medium">Stories Live</p>
              </div>
              <div>
                <p className="font-serif text-2xl font-bold text-stone-900 dark:text-stone-100">4</p>
                <p className="text-xs text-stone-500 dark:text-stone-400 font-medium">Core Niches</p>
              </div>
              <div>
                <p className="font-serif text-2xl font-bold text-stone-900 dark:text-stone-100">Bankura</p>
                <p className="text-xs text-stone-500 dark:text-stone-400 font-medium">Simlapal Roots</p>
              </div>
            </div>

          </div>

          {/* Right Column: Editorial Visual Card */}
          <div className="lg:col-span-5 flex flex-col items-center">
            <div className="relative w-full max-w-md">
              
              {/* Outer decorative frame */}
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-white bg-stone-900 dark:border-stone-800 transition-all">
                
                {/* Photo Viewer */}
                <div className="relative aspect-[3/4] w-full overflow-hidden bg-stone-950">
                  <img
                    src={displayImage}
                    alt="Kousik Satpathi"
                    className="h-full w-full object-cover object-center transition-all duration-700 ease-out hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
                  
                  {/* Photo Switcher Pill */}
                  <div className="absolute top-4 right-4 z-10 flex rounded-lg bg-stone-950/70 p-1 backdrop-blur-md border border-white/10 text-xs">
                    <button
                      onClick={() => setActivePhoto('rider')}
                      className={`px-2.5 py-1 rounded font-medium transition-all ${
                        activePhoto === 'rider'
                          ? 'bg-amber-600 text-white shadow-xs'
                          : 'text-stone-300 hover:text-white'
                      }`}
                    >
                      Travel Ride
                    </button>
                    <button
                      onClick={() => setActivePhoto('portrait')}
                      className={`px-2.5 py-1 rounded font-medium transition-all ${
                        activePhoto === 'portrait'
                          ? 'bg-amber-600 text-white shadow-xs'
                          : 'text-stone-300 hover:text-white'
                      }`}
                    >
                      Portrait
                    </button>
                  </div>

                  {/* Photo Caption Overlay */}
                  <div className="absolute bottom-4 left-4 right-4 text-left text-white">
                    <div className="flex items-center gap-2 mb-1">
                      <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded bg-amber-600/90 text-white">
                        {activePhoto === 'rider' ? 'Yamaha Explorer' : 'Content Creator'}
                      </span>
                      <span className="text-xs text-stone-300">Simlapal, West Bengal</span>
                    </div>
                    <p className="font-serif text-sm italic text-stone-200">
                      «“{author.quote.replace(/[«“»”]/g, '')}”»
                    </p>
                  </div>
                </div>
              </div>

              {/* Hanging Quote Ribbon */}
              <div className="mt-4 flex items-center justify-between rounded-xl border border-stone-200/90 bg-white/90 p-3.5 shadow-sm dark:border-stone-800 dark:bg-stone-900/90">
                <div className="flex items-center gap-2.5">
                  <Quote className="h-5 w-5 text-amber-600 dark:text-amber-400 shrink-0" />
                  <p className="text-xs font-semibold text-stone-700 dark:text-stone-300">
                    {author.motto}
                  </p>
                </div>
                <div className="flex items-center gap-1.5">
                  <a
                    href={author.socials.facebook}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex h-7 w-7 items-center justify-center rounded-md bg-stone-100 text-stone-700 hover:bg-blue-50 hover:text-blue-600 transition-colors dark:bg-stone-800 dark:text-stone-300"
                    title="Facebook"
                  >
                    <span className="font-bold text-xs">f</span>
                  </a>
                  <a
                    href={author.socials.instagram}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex h-7 w-7 items-center justify-center rounded-md bg-stone-100 text-stone-700 hover:bg-pink-50 hover:text-pink-600 transition-colors dark:bg-stone-800 dark:text-stone-300"
                    title="Instagram"
                  >
                    <span className="font-bold text-xs">ig</span>
                  </a>
                </div>
              </div>

            </div>
          </div>

        </div>
      </div>
    </section>
  );
};
