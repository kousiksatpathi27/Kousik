import React, { useState } from 'react';
import { 
  X, 
  Heart, 
  Share2, 
  Check, 
  MessageCircle, 
  Clock, 
  Calendar, 
  Tag, 
  Pin, 
  Edit, 
  Trash2,
  Send,
  User,
  ArrowLeft,
  Bookmark
} from 'lucide-react';
import { BlogPost } from '../types/blog';

interface PostReaderModalProps {
  post: BlogPost | null;
  onClose: () => void;
  onLike: (postId: string) => void;
  onAddComment: (postId: string, author: string, content: string) => void;
  onEdit: (post: BlogPost) => void;
  onDelete: (postId: string) => void;
}

export const PostReaderModal: React.FC<PostReaderModalProps> = ({
  post,
  onClose,
  onLike,
  onAddComment,
  onEdit,
  onDelete,
}) => {
  const [commentName, setCommentName] = useState('');
  const [commentBody, setCommentBody] = useState('');
  const [copiedLink, setCopiedLink] = useState(false);
  const [isBookmarked, setIsBookmarked] = useState(false);
  const [hasLiked, setHasLiked] = useState(false);

  if (!post) return null;

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  const handleShareFacebook = () => {
    const url = encodeURIComponent(window.location.href);
    window.open(`https://www.facebook.com/sharer/sharer.php?u=${url}`, '_blank');
  };

  const handleShareWhatsApp = () => {
    const text = encodeURIComponent(`Read "${post.title}" by Kousik Satpathi:\n${window.location.href}`);
    window.open(`https://api.whatsapp.com/send?text=${text}`, '_blank');
  };

  const handleLikeClick = () => {
    if (!hasLiked) {
      setHasLiked(true);
      onLike(post.id);
    }
  };

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!commentName.trim() || !commentBody.trim()) return;
    onAddComment(post.id, commentName.trim(), commentBody.trim());
    setCommentName('');
    setCommentBody('');
  };

  // Simple Markdown parser for clean editorial presentation
  const renderFormattedContent = (rawText: string) => {
    const paragraphs = rawText.split('\n\n');
    return paragraphs.map((block, index) => {
      const trimmed = block.trim();
      if (!trimmed) return null;

      // Heading 3
      if (trimmed.startsWith('### ')) {
        return (
          <h3 key={index} className="font-serif text-2xl font-bold text-stone-900 dark:text-stone-100 mt-8 mb-4">
            {trimmed.replace(/^###\s+/, '')}
          </h3>
        );
      }

      // Heading 2
      if (trimmed.startsWith('## ')) {
        return (
          <h2 key={index} className="font-serif text-3xl font-bold text-stone-900 dark:text-stone-100 mt-10 mb-4 pb-2 border-b border-stone-200 dark:border-stone-800">
            {trimmed.replace(/^##\s+/, '')}
          </h2>
        );
      }

      // Blockquote
      if (trimmed.startsWith('> ')) {
        return (
          <blockquote key={index} className="border-l-4 border-amber-600 bg-amber-50/50 p-4 rounded-r-lg my-6 italic text-stone-800 dark:bg-amber-950/20 dark:text-amber-200 dark:border-amber-500 font-serif text-lg">
            {trimmed.replace(/^>\s+/, '')}
          </blockquote>
        );
      }

      // Bullet lists
      if (trimmed.startsWith('- ') || trimmed.startsWith('* ')) {
        const items = trimmed.split('\n').filter(Boolean);
        return (
          <ul key={index} className="list-disc pl-6 space-y-2 my-4 text-stone-700 dark:text-stone-300">
            {items.map((it, i) => (
              <li key={i}>{it.replace(/^[-*]\s+/, '')}</li>
            ))}
          </ul>
        );
      }

      // Numbered lists
      if (/^\d+\.\s/.test(trimmed)) {
        const items = trimmed.split('\n').filter(Boolean);
        return (
          <ol key={index} className="list-decimal pl-6 space-y-2 my-4 text-stone-700 dark:text-stone-300">
            {items.map((it, i) => (
              <li key={i}>{it.replace(/^\d+\.\s+/, '')}</li>
            ))}
          </ol>
        );
      }

      // Standard paragraph with bold parsing
      return (
        <p key={index} className="text-base sm:text-lg leading-relaxed text-stone-700 dark:text-stone-300 my-4">
          {trimmed}
        </p>
      );
    });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 md:p-6 overflow-y-auto bg-stone-900/70 backdrop-blur-md animate-fade-in">
      <div 
        className="relative w-full max-w-4xl my-auto rounded-2xl bg-white shadow-2xl border border-stone-200 dark:border-stone-800 dark:bg-stone-900 overflow-hidden flex flex-col max-h-[94vh]"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Top Control Bar */}
        <div className="sticky top-0 z-20 flex items-center justify-between border-b border-stone-200/90 bg-white/95 px-6 py-3.5 backdrop-blur-md dark:border-stone-800 dark:bg-stone-900/95">
          <button
            onClick={onClose}
            className="flex items-center gap-1.5 text-xs font-semibold text-stone-600 hover:text-stone-900 dark:text-stone-400 dark:hover:text-stone-100 transition-colors"
          >
            <ArrowLeft className="h-4 w-4" />
            <span>Back to Stories</span>
          </button>

          <div className="flex items-center gap-2">
            {/* Edit / Delete CMS tools for Kousik */}
            <button
              onClick={() => {
                onClose();
                onEdit(post);
              }}
              className="flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-medium text-stone-600 hover:bg-stone-100 dark:text-stone-300 dark:hover:bg-stone-800"
              title="Edit post"
            >
              <Edit className="h-3.5 w-3.5" />
              <span>Edit</span>
            </button>

            <button
              onClick={() => {
                if (window.confirm('Are you sure you want to delete this story?')) {
                  onDelete(post.id);
                  onClose();
                }
              }}
              className="flex items-center gap-1 rounded-lg px-2.5 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40"
              title="Delete post"
            >
              <Trash2 className="h-3.5 w-3.5" />
              <span>Delete</span>
            </button>

            <div className="h-4 w-px bg-stone-200 dark:bg-stone-800 mx-1" />

            {/* Bookmark button */}
            <button
              onClick={() => setIsBookmarked(!isBookmarked)}
              className={`rounded-lg p-1.5 transition-colors ${
                isBookmarked
                  ? 'text-amber-600 dark:text-amber-400'
                  : 'text-stone-400 hover:text-stone-700 dark:hover:text-stone-200'
              }`}
              title={isBookmarked ? 'Saved to bookmarks' : 'Bookmark story'}
            >
              <Bookmark className={`h-4 w-4 ${isBookmarked ? 'fill-current' : ''}`} />
            </button>

            {/* Close button */}
            <button
              onClick={onClose}
              className="rounded-lg p-1.5 text-stone-400 hover:bg-stone-100 hover:text-stone-700 dark:hover:bg-stone-800 dark:hover:text-stone-200"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Reader Body */}
        <div className="overflow-y-auto flex-1">
          
          {/* Hero Banner Image */}
          <div className="relative aspect-[21/9] sm:aspect-[16/7] w-full overflow-hidden bg-stone-900">
            <img
              src={post.coverImage}
              alt={post.title}
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-transparent to-black/20" />
            
            {post.isPinned && (
              <div className="absolute top-4 left-6 inline-flex items-center gap-1 rounded-md bg-amber-600/90 px-2.5 py-1 text-xs font-semibold text-white shadow-sm backdrop-blur-xs">
                <Pin className="h-3 w-3" />
                <span>Pinned Story</span>
              </div>
            )}
          </div>

          {/* Article Header & Typography */}
          <article className="mx-auto max-w-3xl px-6 py-8 sm:py-10">
            
            {/* Metadata clean unboxed row */}
            <div className="flex flex-wrap items-center gap-3 text-xs text-stone-500 dark:text-stone-400 mb-4">
              <span className="font-bold text-amber-700 dark:text-amber-400 uppercase tracking-wider">
                {post.category}
              </span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <Calendar className="h-3.5 w-3.5" />
                {post.publishedAt}
              </span>
              <span>·</span>
              <span className="flex items-center gap-1">
                <Clock className="h-3.5 w-3.5" />
                {post.readTime}
              </span>
              <span>·</span>
              <span>{post.views} views</span>
            </div>

            {/* Article Headline */}
            <h1 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-stone-900 dark:text-stone-100 leading-tight mb-6">
              {post.title}
            </h1>

            {/* Author Byline */}
            <div className="flex items-center justify-between border-y border-stone-200 py-4 mb-8 dark:border-stone-800">
              <div className="flex items-center gap-3">
                <div className="h-11 w-11 rounded-full bg-stone-900 text-stone-100 dark:bg-stone-100 dark:text-stone-900 font-serif font-bold text-lg flex items-center justify-center shrink-0">
                  KS
                </div>
                <div>
                  <p className="font-serif text-sm font-bold text-stone-900 dark:text-stone-100">
                    Kousik Satpathi
                  </p>
                  <p className="text-xs text-stone-500 dark:text-stone-400">
                    Simlapal, Bankura • Blogger & Content Creator
                  </p>
                </div>
              </div>

              {/* Action Reactions */}
              <div className="flex items-center gap-2">
                <button
                  onClick={handleLikeClick}
                  className={`flex items-center gap-1.5 rounded-lg border px-3 py-1.5 text-xs font-semibold transition-all ${
                    hasLiked
                      ? 'border-red-200 bg-red-50 text-red-600 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-400'
                      : 'border-stone-200 bg-white text-stone-700 hover:bg-stone-50 dark:border-stone-700 dark:bg-stone-800 dark:text-stone-200'
                  }`}
                >
                  <Heart className={`h-4 w-4 ${hasLiked ? 'fill-current text-red-500' : ''}`} />
                  <span>{post.likes}</span>
                </button>

                <button
                  onClick={handleCopyLink}
                  className="rounded-lg border border-stone-200 bg-white p-1.5 text-stone-600 hover:bg-stone-50 dark:border-stone-700 dark:bg-stone-800 dark:text-stone-300"
                  title="Copy Story Link"
                >
                  {copiedLink ? <Check className="h-4 w-4 text-emerald-600" /> : <Share2 className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {/* Excerpt Lead */}
            {post.excerpt && (
              <p className="text-lg sm:text-xl font-medium text-stone-600 dark:text-stone-300 italic mb-8 border-l-2 border-amber-600 pl-4 py-1">
                {post.excerpt}
              </p>
            )}

            {/* Full Formatted Article Content */}
            <div className="article-body">
              {renderFormattedContent(post.content)}
            </div>

            {/* Tags Strip */}
            <div className="mt-10 pt-6 border-t border-stone-200 dark:border-stone-800">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-xs font-semibold uppercase text-stone-400">Tags:</span>
                {post.tags.map((tag) => (
                  <span
                    key={tag}
                    className="text-xs text-stone-600 hover:text-amber-700 dark:text-stone-400 dark:hover:text-amber-400 cursor-pointer font-mono"
                  >
                    #{tag}
                  </span>
                ))}
              </div>
            </div>

            {/* Share this story prompt */}
            <div className="mt-8 rounded-xl bg-stone-100/70 p-5 dark:bg-stone-800/50 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div>
                <p className="font-serif font-bold text-stone-900 dark:text-stone-100 text-sm">
                  Enjoyed this story by Kousik?
                </p>
                <p className="text-xs text-stone-500 dark:text-stone-400">
                  Share it with friends or on social media to spread the word.
                </p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleShareFacebook}
                  className="px-3 py-1.5 rounded-lg bg-blue-600 text-white text-xs font-semibold hover:bg-blue-700 transition-colors"
                >
                  Facebook
                </button>
                <button
                  onClick={handleShareWhatsApp}
                  className="px-3 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-semibold hover:bg-emerald-700 transition-colors"
                >
                  WhatsApp
                </button>
                <button
                  onClick={handleCopyLink}
                  className="px-3 py-1.5 rounded-lg border border-stone-300 bg-white text-stone-700 text-xs font-semibold hover:bg-stone-50 dark:border-stone-700 dark:bg-stone-800 dark:text-stone-300"
                >
                  {copiedLink ? 'Copied!' : 'Copy Link'}
                </button>
              </div>
            </div>

            {/* Comments Section */}
            <section className="mt-12 pt-8 border-t border-stone-200 dark:border-stone-800">
              <div className="flex items-center gap-2 mb-6">
                <MessageCircle className="h-5 w-5 text-amber-600 dark:text-amber-400" />
                <h3 className="font-serif text-xl font-bold text-stone-900 dark:text-stone-100">
                  Comments & Thoughts ({post.comments.length})
                </h3>
              </div>

              {/* Leave a comment form */}
              <form onSubmit={handleCommentSubmit} className="mb-8 rounded-xl border border-stone-200 bg-stone-50/70 p-4 dark:border-stone-800 dark:bg-stone-950/40">
                <p className="text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-3">
                  Leave a Comment
                </p>
                <div className="space-y-3">
                  <input
                    type="text"
                    value={commentName}
                    onChange={(e) => setCommentName(e.target.value)}
                    placeholder="Your Name (e.g. Rahul Mukherjee)"
                    required
                    className="w-full rounded-lg border border-stone-300 px-3 py-2 text-xs text-stone-900 placeholder-stone-400 focus:border-amber-500 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
                  />
                  <textarea
                    rows={3}
                    value={commentBody}
                    onChange={(e) => setCommentBody(e.target.value)}
                    placeholder="Write your feedback or reaction to this post..."
                    required
                    className="w-full rounded-lg border border-stone-300 px-3 py-2 text-xs text-stone-900 placeholder-stone-400 focus:border-amber-500 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
                  />
                  <div className="flex justify-end">
                    <button
                      type="submit"
                      className="inline-flex items-center gap-1.5 rounded-lg bg-amber-600 px-4 py-2 text-xs font-semibold text-white hover:bg-amber-700 transition-colors dark:bg-amber-500 dark:hover:bg-amber-600"
                    >
                      <Send className="h-3 w-3" />
                      <span>Post Comment</span>
                    </button>
                  </div>
                </div>
              </form>

              {/* Comments List */}
              <div className="space-y-4">
                {post.comments.length === 0 ? (
                  <p className="text-xs text-stone-400 italic">
                    No comments yet. Be the first to share your thoughts with Kousik!
                  </p>
                ) : (
                  post.comments.map((comment) => (
                    <div
                      key={comment.id}
                      className="rounded-xl border border-stone-200/80 bg-white p-4 dark:border-stone-800 dark:bg-stone-900/60 shadow-2xs"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <div className="flex h-7 w-7 items-center justify-center rounded-full bg-amber-100 text-amber-800 text-xs font-bold dark:bg-amber-950 dark:text-amber-300">
                            {comment.author.charAt(0).toUpperCase()}
                          </div>
                          <span className="text-xs font-bold text-stone-800 dark:text-stone-200">
                            {comment.author}
                          </span>
                        </div>
                        <span className="text-[11px] text-stone-400 font-mono">
                          {comment.createdAt}
                        </span>
                      </div>
                      <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-300 leading-relaxed pl-9">
                        {comment.content}
                      </p>
                    </div>
                  ))
                )}
              </div>
            </section>

          </article>
        </div>

      </div>
    </div>
  );
};
