import React, { useState } from 'react';
import { 
  Search, 
  LayoutGrid, 
  List, 
  ArrowRight, 
  Heart, 
  Share2, 
  Clock, 
  Calendar, 
  Pin, 
  Edit, 
  Trash2, 
  MessageSquare,
  Sparkles,
  SlidersHorizontal,
  X
} from 'lucide-react';
import { BlogPost, Category } from '../types/blog';

interface BlogFeedProps {
  posts: BlogPost[];
  selectedCategory: string;
  onSelectCategory: (category: string) => void;
  onReadPost: (post: BlogPost) => void;
  onOpenCreateModal: () => void;
  onLikePost: (postId: string) => void;
  onEditPost: (post: BlogPost) => void;
  onDeletePost: (postId: string) => void;
}

export const BlogFeed: React.FC<BlogFeedProps> = ({
  posts,
  selectedCategory,
  onSelectCategory,
  onReadPost,
  onOpenCreateModal,
  onLikePost,
  onEditPost,
  onDeletePost,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [sortBy, setSortBy] = useState<'newest' | 'likes' | 'views'>('newest');

  const categories: (Category | 'All')[] = [
    'All',
    'Lifestyle',
    'Travel',
    'Technology',
    'Personal Stories',
  ];

  // Filter posts
  const filteredPosts = posts.filter((post) => {
    const matchesCategory =
      selectedCategory === 'All' || post.category === selectedCategory;

    const matchesSearch =
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()));

    return matchesCategory && matchesSearch;
  });

  // Sort posts
  const sortedPosts = [...filteredPosts].sort((a, b) => {
    if (sortBy === 'likes') return b.likes - a.likes;
    if (sortBy === 'views') return b.views - a.views;
    // Newest first (pinned posts get slight priority on 'All')
    if (a.isPinned && !b.isPinned) return -1;
    if (!a.isPinned && b.isPinned) return 1;
    return new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime();
  });

  // Calculate counts per category
  const getCategoryCount = (cat: Category | 'All') => {
    if (cat === 'All') return posts.length;
    return posts.filter((p) => p.category === cat).length;
  };

  return (
    <section id="posts" className="py-16 sm:py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      {/* Section Title & Subtitle */}
      <div className="flex flex-col md:flex-row md:items-end justify-between mb-8 pb-6 border-b border-stone-200 dark:border-stone-800 gap-4">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
            Journal & Feed
          </span>
          <h2 className="font-serif text-3xl sm:text-4xl font-bold tracking-tight text-stone-900 dark:text-stone-100 mt-1">
            Latest Stories & Articles
          </h2>
          <p className="text-sm text-stone-500 dark:text-stone-400 mt-1">
            Explore thoughts, bike tours, tech gear & lessons from Bankura and beyond.
          </p>
        </div>

        <button
          onClick={onOpenCreateModal}
          className="inline-flex items-center gap-2 self-start md:self-auto rounded-lg bg-stone-900 px-4 py-2 text-xs font-semibold text-white shadow-xs hover:bg-stone-800 dark:bg-stone-100 dark:text-stone-900 dark:hover:bg-white transition-colors"
        >
          <span>Write a Story</span>
          <span className="text-stone-400 dark:text-stone-600 font-mono">+</span>
        </button>
      </div>

      {/* Filter Bar & Controls */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 mb-8">
        
        {/* Category Tabs (Clean text / pill interactive filter) */}
        <div className="flex items-center gap-1 overflow-x-auto pb-2 lg:pb-0 scrollbar-none">
          {categories.map((cat) => {
            const isSelected = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => onSelectCategory(cat)}
                className={`whitespace-nowrap rounded-lg px-3.5 py-1.5 text-xs font-semibold transition-all ${
                  isSelected
                    ? 'bg-amber-600 text-white shadow-2xs dark:bg-amber-500'
                    : 'bg-white text-stone-600 border border-stone-200 hover:border-stone-300 hover:text-stone-900 dark:bg-stone-900 dark:border-stone-800 dark:text-stone-300 dark:hover:border-stone-700'
                }`}
              >
                <span>{cat}</span>
                <span className={`ml-1.5 text-[11px] font-mono ${isSelected ? 'text-amber-100' : 'text-stone-400'}`}>
                  {getCategoryCount(cat)}
                </span>
              </button>
            );
          })}
        </div>

        {/* Search, Sort & View Mode */}
        <div className="flex flex-wrap items-center gap-2 sm:gap-3">
          
          {/* Search Box */}
          <div className="relative flex-1 sm:w-60">
            <Search className="absolute left-3 top-2.5 h-3.5 w-3.5 text-stone-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search stories, tags..."
              className="w-full rounded-lg border border-stone-200 bg-white pl-8 pr-7 py-1.5 text-xs text-stone-900 placeholder-stone-400 focus:border-amber-500 focus:outline-none dark:border-stone-800 dark:bg-stone-900 dark:text-stone-100"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-2.5 top-2.5 text-stone-400 hover:text-stone-600"
              >
                <X className="h-3 w-3" />
              </button>
            )}
          </div>

          {/* Sort Selector */}
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="rounded-lg border border-stone-200 bg-white px-3 py-1.5 text-xs font-medium text-stone-700 focus:border-amber-500 focus:outline-none dark:border-stone-800 dark:bg-stone-900 dark:text-stone-300"
          >
            <option value="newest">Newest First</option>
            <option value="likes">Most Liked</option>
            <option value="views">Most Views</option>
          </select>

          {/* View Mode Toggle */}
          <div className="flex rounded-lg border border-stone-200 bg-white p-0.5 dark:border-stone-800 dark:bg-stone-900">
            <button
              onClick={() => setViewMode('grid')}
              className={`rounded p-1 text-xs transition-colors ${
                viewMode === 'grid'
                  ? 'bg-stone-100 text-stone-900 dark:bg-stone-800 dark:text-stone-100'
                  : 'text-stone-400 hover:text-stone-600 dark:hover:text-stone-300'
              }`}
              title="Grid View"
            >
              <LayoutGrid className="h-3.5 w-3.5" />
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`rounded p-1 text-xs transition-colors ${
                viewMode === 'list'
                  ? 'bg-stone-100 text-stone-900 dark:bg-stone-800 dark:text-stone-100'
                  : 'text-stone-400 hover:text-stone-600 dark:hover:text-stone-300'
              }`}
              title="Magazine List View"
            >
              <List className="h-3.5 w-3.5" />
            </button>
          </div>

        </div>

      </div>

      {/* Empty State */}
      {sortedPosts.length === 0 && (
        <div className="rounded-2xl border border-dashed border-stone-300 p-12 text-center dark:border-stone-800 bg-stone-50/50 dark:bg-stone-900/30">
          <p className="font-serif text-lg font-bold text-stone-800 dark:text-stone-200 mb-2">
            No stories found matching your filter
          </p>
          <p className="text-xs text-stone-500 dark:text-stone-400 mb-6 max-w-sm mx-auto">
            {searchQuery
              ? `No results for "${searchQuery}". Try a different keyword.`
              : `You haven't posted any stories under ${selectedCategory} yet.`}
          </p>
          <div className="flex justify-center gap-3">
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="px-3.5 py-1.5 rounded-lg border border-stone-300 text-xs font-semibold text-stone-700 hover:bg-stone-100 dark:border-stone-700 dark:text-stone-300"
              >
                Clear Search
              </button>
            )}
            <button
              onClick={onOpenCreateModal}
              className="px-4 py-2 rounded-lg bg-amber-600 text-xs font-semibold text-white hover:bg-amber-700 transition-colors"
            >
              Publish a New Post
            </button>
          </div>
        </div>
      )}

      {/* Grid View */}
      {viewMode === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {sortedPosts.map((post) => (
            <article
              key={post.id}
              className="group flex flex-col rounded-2xl border border-stone-200/90 bg-white overflow-hidden shadow-2xs hover:shadow-xl transition-all duration-300 dark:border-stone-800 dark:bg-stone-900"
            >
              {/* Card Cover Image with zoom */}
              <div 
                onClick={() => onReadPost(post)}
                className="relative aspect-[16/10] w-full overflow-hidden bg-stone-100 cursor-pointer dark:bg-stone-800"
              >
                <img
                  src={post.coverImage}
                  alt={post.title}
                  loading="lazy"
                  className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-stone-950/60 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />

                {post.isPinned && (
                  <div className="absolute top-3 left-3 inline-flex items-center gap-1 rounded bg-amber-600 px-2 py-0.5 text-[11px] font-semibold text-white shadow-2xs">
                    <Pin className="h-3 w-3" />
                    <span>Pinned</span>
                  </div>
                )}
              </div>

              {/* Card Content */}
              <div className="flex flex-1 flex-col p-6">
                
                {/* Metadata unboxed row */}
                <div className="flex items-center gap-2 text-[11px] font-medium text-stone-500 dark:text-stone-400 mb-2">
                  <span className="font-bold text-amber-700 dark:text-amber-400 uppercase tracking-wider">
                    {post.category}
                  </span>
                  <span>·</span>
                  <span>{post.publishedAt}</span>
                  <span>·</span>
                  <span>{post.readTime}</span>
                </div>

                {/* Title */}
                <h3 
                  onClick={() => onReadPost(post)}
                  className="font-serif text-xl font-bold tracking-tight text-stone-900 group-hover:text-amber-700 dark:text-stone-100 dark:group-hover:text-amber-400 transition-colors cursor-pointer line-clamp-2 leading-snug mb-3"
                >
                  {post.title}
                </h3>

                {/* Excerpt */}
                <p className="text-sm text-stone-600 dark:text-stone-300 line-clamp-3 leading-relaxed mb-4 flex-1">
                  {post.excerpt}
                </p>

                {/* Tags Strip */}
                <div className="flex flex-wrap gap-1.5 mb-5">
                  {post.tags.slice(0, 3).map((tag) => (
                    <span
                      key={tag}
                      className="text-[11px] text-stone-500 dark:text-stone-400 font-mono"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>

                {/* Card Footer: Actions */}
                <div className="flex items-center justify-between border-t border-stone-100 pt-4 dark:border-stone-800/80">
                  <button
                    onClick={() => onReadPost(post)}
                    className="inline-flex items-center gap-1 text-xs font-bold text-stone-900 hover:text-amber-700 dark:text-stone-200 dark:hover:text-amber-400 transition-colors"
                  >
                    <span>Read Story</span>
                    <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                  </button>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => onLikePost(post.id)}
                      className="flex items-center gap-1 text-xs text-stone-500 hover:text-red-500 transition-colors"
                      title="Like this post"
                    >
                      <Heart className="h-3.5 w-3.5" />
                      <span>{post.likes}</span>
                    </button>

                    <button
                      onClick={() => onReadPost(post)}
                      className="flex items-center gap-1 text-xs text-stone-500 hover:text-stone-800 dark:hover:text-stone-300"
                      title="Comments"
                    >
                      <MessageSquare className="h-3.5 w-3.5" />
                      <span>{post.comments.length}</span>
                    </button>

                    <button
                      onClick={() => onEditPost(post)}
                      className="text-stone-400 hover:text-stone-700 dark:hover:text-stone-200"
                      title="Edit Story"
                    >
                      <Edit className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>

              </div>
            </article>
          ))}
        </div>
      ) : (
        /* Magazine List View */
        <div className="space-y-4">
          {sortedPosts.map((post) => (
            <article
              key={post.id}
              className="group flex flex-col sm:flex-row items-stretch rounded-xl border border-stone-200/90 bg-white overflow-hidden shadow-2xs hover:shadow-md transition-all dark:border-stone-800 dark:bg-stone-900"
            >
              <div 
                onClick={() => onReadPost(post)}
                className="relative sm:w-56 shrink-0 aspect-[16/10] sm:aspect-auto overflow-hidden bg-stone-100 cursor-pointer dark:bg-stone-800"
              >
                <img
                  src={post.coverImage}
                  alt={post.title}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>

              <div className="flex flex-1 flex-col justify-between p-5 sm:p-6">
                <div>
                  <div className="flex items-center gap-2 text-[11px] font-medium text-stone-500 dark:text-stone-400 mb-1.5">
                    <span className="font-bold text-amber-700 dark:text-amber-400 uppercase tracking-wider">
                      {post.category}
                    </span>
                    <span>·</span>
                    <span>{post.publishedAt}</span>
                    <span>·</span>
                    <span>{post.readTime}</span>
                  </div>

                  <h3 
                    onClick={() => onReadPost(post)}
                    className="font-serif text-lg sm:text-xl font-bold tracking-tight text-stone-900 group-hover:text-amber-700 dark:text-stone-100 dark:group-hover:text-amber-400 transition-colors cursor-pointer mb-2"
                  >
                    {post.title}
                  </h3>

                  <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-300 line-clamp-2 leading-relaxed mb-3">
                    {post.excerpt}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-stone-100 dark:border-stone-800">
                  <button
                    onClick={() => onReadPost(post)}
                    className="inline-flex items-center gap-1 text-xs font-bold text-stone-900 hover:text-amber-700 dark:text-stone-200 dark:hover:text-amber-400"
                  >
                    <span>Read Article</span>
                    <ArrowRight className="h-3 w-3" />
                  </button>

                  <div className="flex items-center gap-3">
                    <button
                      onClick={() => onLikePost(post.id)}
                      className="flex items-center gap-1 text-xs text-stone-500 hover:text-red-500"
                    >
                      <Heart className="h-3.5 w-3.5" />
                      <span>{post.likes}</span>
                    </button>
                    <button
                      onClick={() => onEditPost(post)}
                      className="text-stone-400 hover:text-stone-700 dark:hover:text-stone-200"
                    >
                      <Edit className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>

              </div>
            </article>
          ))}
        </div>
      )}

    </section>
  );
};
