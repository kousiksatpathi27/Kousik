import React, { useState, useEffect } from 'react';
import { 
  X, 
  Upload, 
  Image as ImageIcon, 
  Sparkles, 
  Eye, 
  Edit3, 
  Check, 
  Pin,
  Clock,
  Tag,
  AlertCircle
} from 'lucide-react';
import { BlogPost, Category } from '../types/blog';
import { samplePresetImages } from '../data/blogData';

interface CreatePostModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSavePost: (post: BlogPost) => void;
  initialPost?: BlogPost | null;
}

export const CreatePostModal: React.FC<CreatePostModalProps> = ({
  isOpen,
  onClose,
  onSavePost,
  initialPost,
}) => {
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<Category>('Travel');
  const [excerpt, setExcerpt] = useState('');
  const [content, setContent] = useState('');
  const [selectedImage, setSelectedImage] = useState(samplePresetImages[0].url);
  const [customImageUrl, setCustomImageUrl] = useState('');
  const [tagsInput, setTagsInput] = useState('TravelStory, Bankura');
  const [isPinned, setIsPinned] = useState(false);
  const [activeTab, setActiveTab] = useState<'edit' | 'preview'>('edit');
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    if (initialPost) {
      setTitle(initialPost.title);
      setCategory(initialPost.category);
      setExcerpt(initialPost.excerpt);
      setContent(initialPost.content);
      setSelectedImage(initialPost.coverImage);
      setTagsInput(initialPost.tags.join(', '));
      setIsPinned(!!initialPost.isPinned);
    } else {
      // Defaults for brand new post
      setTitle('');
      setCategory('Travel');
      setExcerpt('');
      setContent('');
      setSelectedImage(samplePresetImages[0].url);
      setCustomImageUrl('');
      setTagsInput('Bankura, TravelDiaries');
      setIsPinned(false);
    }
    setErrors({});
    setActiveTab('edit');
  }, [initialPost, isOpen]);

  if (!isOpen) return null;

  // Calculate read time
  const wordCount = (content.trim().split(/\s+/).filter(Boolean).length) || 0;
  const calculatedReadTime = `${Math.max(1, Math.ceil(wordCount / 180))} min read`;

  // Handle local file upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        if (typeof reader.result === 'string') {
          setSelectedImage(reader.result);
          setCustomImageUrl('');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const insertFormatting = (prefix: string, suffix: string = '') => {
    const textarea = document.getElementById('post-content-area') as HTMLTextAreaElement | null;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const previous = textarea.value;
    const selected = previous.substring(start, end) || 'text';
    const replacement = `${prefix}${selected}${suffix}`;

    const updated = previous.substring(0, start) + replacement + previous.substring(end);
    setContent(updated);

    setTimeout(() => {
      textarea.focus();
      textarea.setSelectionRange(start + prefix.length, start + prefix.length + selected.length);
    }, 10);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: { [key: string]: string } = {};

    if (!title.trim()) newErrors.title = 'Title is required';
    if (!content.trim()) newErrors.content = 'Article content is required';

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    const cleanedTags = tagsInput
      .split(',')
      .map((t) => t.trim().replace(/^#/, ''))
      .filter(Boolean);

    const postCover = customImageUrl.trim() ? customImageUrl.trim() : selectedImage;

    const postPayload: BlogPost = {
      id: initialPost ? initialPost.id : `post-${Date.now()}`,
      title: title.trim(),
      slug: (title.trim().toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '')) || `post-${Date.now()}`,
      category,
      excerpt: excerpt.trim() || content.trim().slice(0, 150) + '...',
      content: content.trim(),
      coverImage: postCover,
      readTime: calculatedReadTime,
      publishedAt: initialPost ? initialPost.publishedAt : new Date().toISOString().split('T')[0],
      tags: cleanedTags.length > 0 ? cleanedTags : [category],
      isPinned,
      likes: initialPost ? initialPost.likes : 0,
      views: initialPost ? initialPost.views + 1 : 1,
      comments: initialPost ? initialPost.comments : [],
      featured: isPinned,
    };

    onSavePost(postPayload);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 md:p-6 overflow-y-auto bg-stone-900/60 backdrop-blur-sm animate-fade-in">
      <div 
        className="relative w-full max-w-3xl my-auto rounded-2xl bg-white shadow-2xl border border-stone-200 dark:border-stone-800 dark:bg-stone-900 overflow-hidden flex flex-col max-h-[92vh]"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-200 px-6 py-4 dark:border-stone-800 bg-stone-50/50 dark:bg-stone-950/40">
          <div>
            <h2 className="font-serif text-xl font-bold text-stone-900 dark:text-stone-100 flex items-center gap-2">
              <Edit3 className="h-5 w-5 text-amber-600 dark:text-amber-400" />
              <span>{initialPost ? 'Edit Blog Post' : 'Create & Publish Post / নতুন পোস্ট'}</span>
            </h2>
            <p className="text-xs text-stone-500 dark:text-stone-400">
              This post will appear instantly on your Home page feed.
            </p>
          </div>
          
          <div className="flex items-center gap-2">
            <div className="flex rounded-lg bg-stone-200/80 p-0.5 dark:bg-stone-800 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setActiveTab('edit')}
                className={`px-3 py-1 rounded-md transition-all ${
                  activeTab === 'edit'
                    ? 'bg-white text-stone-900 shadow-xs dark:bg-stone-700 dark:text-white'
                    : 'text-stone-600 hover:text-stone-900 dark:text-stone-400 dark:hover:text-white'
                }`}
              >
                Write
              </button>
              <button
                type="button"
                onClick={() => setActiveTab('preview')}
                className={`px-3 py-1 rounded-md transition-all ${
                  activeTab === 'preview'
                    ? 'bg-white text-stone-900 shadow-xs dark:bg-stone-700 dark:text-white'
                    : 'text-stone-600 hover:text-stone-900 dark:text-stone-400 dark:hover:text-white'
                }`}
              >
                Preview
              </button>
            </div>
            
            <button
              onClick={onClose}
              className="rounded-lg p-1.5 text-stone-400 hover:bg-stone-100 hover:text-stone-700 dark:hover:bg-stone-800 dark:hover:text-stone-200"
              aria-label="Close modal"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Form Body */}
        <div className="overflow-y-auto p-6 space-y-6 flex-1">
          {activeTab === 'edit' ? (
            <form id="post-form" onSubmit={handleSubmit} className="space-y-5">
              
              {/* Post Title */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1.5">
                  Post Title *
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. My Weekend Ride to Mukutmanipur Dam & Sunset Views"
                  className={`w-full rounded-lg border px-3.5 py-2.5 text-base font-medium text-stone-900 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-amber-500/20 dark:bg-stone-800 dark:text-stone-100 dark:placeholder-stone-500 ${
                    errors.title ? 'border-red-500' : 'border-stone-300 dark:border-stone-700 focus:border-amber-500'
                  }`}
                />
                {errors.title && (
                  <p className="mt-1 text-xs text-red-500 flex items-center gap-1">
                    <AlertCircle className="h-3 w-3" /> {errors.title}
                  </p>
                )}
              </div>

              {/* Category & Pinned Option */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1.5">
                    Category *
                  </label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as Category)}
                    className="w-full rounded-lg border border-stone-300 bg-white px-3.5 py-2.5 text-sm font-medium text-stone-900 focus:border-amber-500 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
                  >
                    <option value="Lifestyle">Lifestyle (Thoughts & Everyday)</option>
                    <option value="Travel">Travel (Rides & Places)</option>
                    <option value="Technology">Technology (Gadgets & Apps)</option>
                    <option value="Personal Stories">Personal Stories (My Journey)</option>
                  </select>
                </div>

                <div className="flex items-center pt-6">
                  <label className="flex items-center gap-2 cursor-pointer select-none text-sm text-stone-700 dark:text-stone-300 font-medium">
                    <input
                      type="checkbox"
                      checked={isPinned}
                      onChange={(e) => setIsPinned(e.target.checked)}
                      className="h-4 w-4 rounded border-stone-300 text-amber-600 focus:ring-amber-500 dark:border-stone-700 dark:bg-stone-800"
                    />
                    <Pin className="h-4 w-4 text-amber-600" />
                    <span>Pin to Top of Home Page</span>
                  </label>
                </div>
              </div>

              {/* Cover Image Selection */}
              <div className="space-y-2">
                <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300">
                  Cover Photography
                </label>
                
                {/* Preset Thumbnails */}
                <div className="grid grid-cols-3 sm:grid-cols-5 gap-2">
                  {samplePresetImages.map((img, idx) => (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setSelectedImage(img.url);
                        setCustomImageUrl('');
                      }}
                      className={`relative aspect-video rounded-lg overflow-hidden border-2 transition-all ${
                        selectedImage === img.url && !customImageUrl
                          ? 'border-amber-600 ring-2 ring-amber-600/30'
                          : 'border-transparent opacity-70 hover:opacity-100'
                      }`}
                    >
                      <img src={img.url} alt={img.label} className="h-full w-full object-cover" />
                      <div className="absolute inset-0 bg-black/20 flex items-end p-1 text-[9px] text-white font-medium truncate">
                        {img.label.split(' ')[0]}
                      </div>
                      {selectedImage === img.url && !customImageUrl && (
                        <div className="absolute top-1 right-1 h-4 w-4 rounded-full bg-amber-600 text-white flex items-center justify-center">
                          <Check className="h-2.5 w-2.5" />
                        </div>
                      )}
                    </button>
                  ))}
                </div>

                {/* Upload or Custom URL row */}
                <div className="flex flex-col sm:flex-row gap-2 pt-1 text-xs">
                  <label className="inline-flex items-center justify-center gap-1.5 rounded-lg border border-stone-300 bg-stone-100/70 px-3 py-2 font-medium text-stone-700 cursor-pointer hover:bg-stone-200 transition-colors dark:border-stone-700 dark:bg-stone-800 dark:text-stone-300 dark:hover:bg-stone-700">
                    <Upload className="h-3.5 w-3.5" />
                    <span>Upload photo from device</span>
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleFileUpload}
                      className="hidden"
                    />
                  </label>
                  
                  <input
                    type="url"
                    value={customImageUrl}
                    onChange={(e) => {
                      setCustomImageUrl(e.target.value);
                      if (e.target.value) setSelectedImage(e.target.value);
                    }}
                    placeholder="Or paste external image URL..."
                    className="flex-1 rounded-lg border border-stone-300 px-3 py-2 text-xs text-stone-900 focus:border-amber-500 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
                  />
                </div>
              </div>

              {/* Excerpt / Summary */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1.5">
                  Brief Excerpt / Summary
                </label>
                <input
                  type="text"
                  value={excerpt}
                  onChange={(e) => setExcerpt(e.target.value)}
                  placeholder="One or two sentences summarizing the story for the feed..."
                  className="w-full rounded-lg border border-stone-300 px-3.5 py-2 text-sm text-stone-900 placeholder-stone-400 focus:border-amber-500 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
                />
              </div>

              {/* Content Area with Markdown toolbar */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300">
                    Full Story / Content *
                  </label>
                  
                  {/* Quick Format toolbar */}
                  <div className="flex items-center gap-1 text-xs">
                    <button
                      type="button"
                      onClick={() => insertFormatting('### ')}
                      className="px-2 py-0.5 rounded bg-stone-100 hover:bg-stone-200 font-bold text-stone-700 dark:bg-stone-800 dark:text-stone-300"
                      title="Add Heading"
                    >
                      H3
                    </button>
                    <button
                      type="button"
                      onClick={() => insertFormatting('**', '**')}
                      className="px-2 py-0.5 rounded bg-stone-100 hover:bg-stone-200 font-bold text-stone-700 dark:bg-stone-800 dark:text-stone-300"
                      title="Bold"
                    >
                      B
                    </button>
                    <button
                      type="button"
                      onClick={() => insertFormatting('> ')}
                      className="px-2 py-0.5 rounded bg-stone-100 hover:bg-stone-200 italic text-stone-700 dark:bg-stone-800 dark:text-stone-300"
                      title="Quote"
                    >
                      Quote
                    </button>
                    <button
                      type="button"
                      onClick={() => insertFormatting('- ')}
                      className="px-2 py-0.5 rounded bg-stone-100 hover:bg-stone-200 text-stone-700 dark:bg-stone-800 dark:text-stone-300"
                      title="List Item"
                    >
                      • List
                    </button>
                  </div>
                </div>

                <textarea
                  id="post-content-area"
                  rows={8}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Share your thoughts, discoveries, route details, tech insights, or personal lessons here..."
                  className={`w-full rounded-lg border p-3.5 text-sm leading-relaxed text-stone-900 placeholder-stone-400 focus:outline-none dark:bg-stone-800 dark:text-stone-100 font-sans ${
                    errors.content ? 'border-red-500' : 'border-stone-300 dark:border-stone-700 focus:border-amber-500'
                  }`}
                />
                
                <div className="flex items-center justify-between mt-1 text-[11px] text-stone-400">
                  <span>{wordCount} words • {calculatedReadTime}</span>
                  <span>Markdown formatting supported (###, **, &gt;, -)</span>
                </div>
              </div>

              {/* Tags Input */}
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-stone-700 dark:text-stone-300 mb-1.5 flex items-center gap-1.5">
                  <Tag className="h-3.5 w-3.5 text-stone-400" />
                  <span>Tags (Comma separated)</span>
                </label>
                <input
                  type="text"
                  value={tagsInput}
                  onChange={(e) => setTagsInput(e.target.value)}
                  placeholder="Bankura, TravelDiaries, Gadgets, LifeLessons"
                  className="w-full rounded-lg border border-stone-300 px-3.5 py-2 text-sm text-stone-900 focus:border-amber-500 focus:outline-none dark:border-stone-700 dark:bg-stone-800 dark:text-stone-100"
                />
              </div>

            </form>
          ) : (
            /* Live Preview */
            <div className="space-y-6">
              <div className="border border-stone-200 dark:border-stone-800 rounded-xl overflow-hidden bg-stone-50/50 dark:bg-stone-950/50">
                <div className="aspect-[16/9] w-full overflow-hidden bg-stone-200">
                  <img
                    src={customImageUrl || selectedImage}
                    alt={title || 'Preview'}
                    className="h-full w-full object-cover"
                  />
                </div>
                <div className="p-6">
                  <div className="flex items-center gap-2 text-xs font-semibold text-amber-700 dark:text-amber-400 uppercase tracking-wider mb-2">
                    <span>{category}</span>
                    <span>•</span>
                    <span className="text-stone-400 font-normal">Today • {calculatedReadTime}</span>
                  </div>
                  <h1 className="font-serif text-2xl sm:text-3xl font-bold text-stone-900 dark:text-stone-100 mb-3">
                    {title || 'Your Post Title Will Appear Here'}
                  </h1>
                  <p className="text-base text-stone-600 dark:text-stone-300 mb-6 italic border-l-2 border-amber-500 pl-3">
                    {excerpt || 'Your excerpt summary preview...'}
                  </p>
                  <div className="prose prose-stone dark:prose-invert max-w-none text-stone-700 dark:text-stone-300 text-sm whitespace-pre-line leading-relaxed">
                    {content || 'Your detailed article content will be rendered here with formatted paragraphs, quotes, and lists.'}
                  </div>
                  <div className="flex flex-wrap gap-1.5 mt-6 pt-4 border-t border-stone-200 dark:border-stone-800">
                    {tagsInput.split(',').filter(Boolean).map((t, idx) => (
                      <span key={idx} className="text-xs text-stone-500 dark:text-stone-400 font-mono">
                        #{t.trim()}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer with Actions */}
        <div className="flex items-center justify-between border-t border-stone-200 bg-stone-50/80 px-6 py-4 dark:border-stone-800 dark:bg-stone-950/80">
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg px-4 py-2 text-sm font-semibold text-stone-600 hover:bg-stone-200/60 dark:text-stone-400 dark:hover:bg-stone-800"
          >
            Cancel
          </button>
          
          <button
            type="submit"
            form="post-form"
            className="flex items-center gap-2 rounded-lg bg-amber-600 px-5 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-amber-700 active:scale-98 transition-all dark:bg-amber-500 dark:hover:bg-amber-600"
          >
            <Check className="h-4 w-4" />
            <span>{initialPost ? 'Save Changes' : 'Publish to Home Page'}</span>
          </button>
        </div>

      </div>
    </div>
  );
};
