import React from 'react';
import { Compass, Cpu, Heart, Feather, ArrowRight } from 'lucide-react';
import { AuthorProfile } from '../types/blog';

interface CategoriesSectionProps {
  categories: AuthorProfile['categories'];
  onSelectCategory: (categoryName: string) => void;
  getPostCountByCategory: (categoryName: string) => number;
}

export const CategoriesSection: React.FC<CategoriesSectionProps> = ({
  categories,
  onSelectCategory,
  getPostCountByCategory,
}) => {
  const getCategoryIcon = (iconName: string) => {
    switch (iconName) {
      case 'Compass':
        return <Compass className="h-6 w-6 text-amber-600 dark:text-amber-400" />;
      case 'Cpu':
        return <Cpu className="h-6 w-6 text-blue-600 dark:text-blue-400" />;
      case 'Heart':
        return <Heart className="h-6 w-6 text-rose-600 dark:text-rose-400" />;
      case 'Feather':
        return <Feather className="h-6 w-6 text-emerald-600 dark:text-emerald-400" />;
      default:
        return <Compass className="h-6 w-6 text-amber-600" />;
    }
  };

  return (
    <section id="categories" className="py-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      
      {/* Header */}
      <div className="max-w-2xl mb-12">
        <span className="text-xs font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">
          Topics & Focus
        </span>
        <h2 className="font-serif text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight text-stone-900 dark:text-stone-100 mt-1">
          What I Write About
        </h2>
        <p className="text-base text-stone-500 dark:text-stone-400 mt-2">
          Dive into my four creative pillars, from motorcycle adventures to digital workflows.
        </p>
      </div>

      {/* 4 Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {categories.map((cat) => {
          const count = getPostCountByCategory(cat.title);
          return (
            <div
              key={cat.title}
              onClick={() => onSelectCategory(cat.title)}
              className="group relative flex flex-col justify-between overflow-hidden rounded-2xl border border-stone-200/90 bg-white shadow-2xs hover:shadow-xl hover:border-amber-500/80 transition-all duration-300 dark:border-stone-800 dark:bg-stone-900 cursor-pointer"
            >
              {/* Cover Image banner */}
              <div className="relative aspect-[16/9] w-full overflow-hidden bg-stone-100 dark:bg-stone-800">
                <img
                  src={cat.cover}
                  alt={cat.title}
                  className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-stone-950/70 via-transparent to-transparent" />
                <div className="absolute top-3 right-3 rounded-md bg-stone-900/80 px-2 py-0.5 text-[10px] font-mono text-white backdrop-blur-xs">
                  {count} {count === 1 ? 'story' : 'stories'}
                </div>
              </div>

              {/* Card Body */}
              <div className="flex flex-1 flex-col justify-between p-6">
                <div>
                  <div className="mb-3">{getCategoryIcon(cat.icon)}</div>
                  <h3 className="font-serif text-xl font-bold text-stone-900 group-hover:text-amber-700 dark:text-stone-100 dark:group-hover:text-amber-400 transition-colors mb-2">
                    {cat.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-stone-600 dark:text-stone-400 leading-relaxed">
                    {cat.description}
                  </p>
                </div>

                <div className="pt-5 mt-4 border-t border-stone-100 dark:border-stone-800/80 flex items-center justify-between text-xs font-bold text-stone-900 dark:text-stone-100 group-hover:text-amber-700 dark:group-hover:text-amber-400">
                  <span>Browse {cat.title}</span>
                  <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                </div>
              </div>
            </div>
          );
        })}
      </div>

    </section>
  );
};
