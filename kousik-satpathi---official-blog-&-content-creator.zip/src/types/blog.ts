export type Category = 'Lifestyle' | 'Travel' | 'Technology' | 'Personal Stories';

export interface Comment {
  id: string;
  author: string;
  content: string;
  createdAt: string;
  avatar?: string;
}

export interface BlogPost {
  id: string;
  title: string;
  slug: string;
  category: Category;
  excerpt: string;
  content: string;
  coverImage: string;
  readTime: string;
  publishedAt: string;
  tags: string[];
  isPinned?: boolean;
  likes: number;
  views: number;
  comments: Comment[];
  featured?: boolean;
}

export interface AuthorProfile {
  name: string;
  tagline: string;
  location: string;
  bioIntro: string;
  aboutFull: string[];
  interests: { label: string; icon: string; desc: string }[];
  categories: {
    title: Category;
    icon: string;
    description: string;
    cover: string;
  }[];
  quote: string;
  socials: {
    facebook: string;
    instagram: string;
    blogspot: string;
    email: string;
  };
  motto: string;
  avatarUrl: string;
  coverHeroUrl: string;
}
