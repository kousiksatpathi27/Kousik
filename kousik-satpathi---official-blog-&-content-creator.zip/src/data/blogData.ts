import { AuthorProfile, BlogPost } from '../types/blog';

import kousikRiderImg from '../assets/images/kousik_hero_rider_1791562248325.jpg';
import kousikPortraitImg from '../assets/images/kousik_portrait_1791562267297.jpg';
import travelBankuraImg from '../assets/images/travel_bankura_1791562312054.jpg';
import techSetupImg from '../assets/images/tech_setup_1791562334214.jpg';
import lifestyleCoffeeImg from '../assets/images/lifestyle_coffee_1791562361929.jpg';

export const authorProfile: AuthorProfile = {
  name: 'Kousik Satpathi',
  tagline: 'Blogger & Content Creator',
  location: 'Simlapal, Bankura, West Bengal, India',
  bioIntro: `Hi, I’m Kousik Satpathi — a blogger and content creator from Bankura, West Bengal. I love exploring new places, learning about technology, capturing moments through photography, and sharing real-life experiences. Through this blog, I write about the things I discover, the lessons I learn, and the stories that inspire me. Welcome to my little corner of the internet. I hope you find something here that informs, inspires, or simply makes your day a little better.`,
  aboutFull: [
    `I started blogging as a way to turn my thoughts, experiences, and ideas into something meaningful.`,
    `What began as a small personal journal slowly grew into a platform where I can share my experiences and connect with people who have similar interests.`,
    `From travel and technology to personal experiences and everyday life, this blog is a collection of things that I enjoy, learn, and discover along the way.`,
    `I believe that every experience has something to teach us, and every story is worth sharing.`
  ],
  interests: [
    { label: 'Travel', icon: 'Plane', desc: 'Discovering hidden rural landscapes & scenic trails across Bengal' },
    { label: 'Technology', icon: 'Laptop', desc: 'Testing new tech, gadgets, productivity workflows & modern web tools' },
    { label: 'Photography', icon: 'Camera', desc: 'Capturing candid road moments, cultural colors & nature frames' },
    { label: 'Books', icon: 'BookOpen', desc: 'Reading essays, self-growth, local literature & inspiring journeys' },
    { label: 'Coffee', icon: 'Coffee', desc: 'Slow mornings fueled by aromatic brewing & mindful thinking' },
    { label: 'Music', icon: 'Music', desc: 'Acoustic melodies, classic rhythm & companion tracks for long road rides' },
  ],
  categories: [
    {
      title: 'Lifestyle',
      icon: 'Heart',
      description: 'Thoughts, experiences, everyday moments, and ideas from life.',
      cover: lifestyleCoffeeImg,
    },
    {
      title: 'Travel',
      icon: 'Compass',
      description: 'Travel experiences, places I explore, travel stories, and useful tips.',
      cover: travelBankuraImg,
    },
    {
      title: 'Technology',
      icon: 'Cpu',
      description: 'Technology, gadgets, useful apps, websites, and interesting tech-related information.',
      cover: techSetupImg,
    },
    {
      title: 'Personal Stories',
      icon: 'Feather',
      description: 'Real-life experiences, thoughts, lessons, and stories from my journey.',
      cover: kousikRiderImg,
    },
  ],
  quote: '“Every journey begins with a single step.”',
  socials: {
    facebook: 'https://facebook.com/kousiksatpathi',
    instagram: 'https://instagram.com/kousiksatpathi',
    blogspot: 'https://www.kousiksatpathi.blogspot.com',
    email: 'kousiksatpathi@gmail.com',
  },
  motto: 'Keep Exploring • Keep Learning • Keep Growing',
  avatarUrl: kousikPortraitImg,
  coverHeroUrl: kousikRiderImg,
};

export const samplePresetImages = [
  { label: 'Riding Journey (Yamaha)', url: kousikRiderImg },
  { label: 'Portrait / Editorial', url: kousikPortraitImg },
  { label: 'Bankura Mukutmanipur Dam', url: travelBankuraImg },
  { label: 'Tech Workspace & Setup', url: techSetupImg },
  { label: 'Lifestyle Coffee & Journal', url: lifestyleCoffeeImg },
];

export const initialBlogPosts: BlogPost[] = [
  {
    id: 'post-1',
    title: 'Solo Ride to Mukutmanipur & Kangsabati: Discovering the Serenity of Bankura',
    slug: 'solo-ride-mukutmanipur-kangsabati-bankura',
    category: 'Travel',
    excerpt: 'Winding through the red soil roads of Bankura on two wheels, catching the crimson sunset where the Kangsabati and Kumari rivers merge.',
    content: `There is a distinct aroma to the red soil of Bankura when the morning dew settles on it. As a rider and storyteller born and raised here, I have always believed that you do not need to travel thousands of miles to find peace. Sometimes, paradise is just a full tank of petrol and an open stretch of highway away.

### The Route from Simlapal
Starting early from Simlapal, the cool morning breeze swept across the open fields. The ride towards Mukutmanipur via Khatra is lined with lush green sal and mahua trees. My bike purred steadily against the asphalt, leaving behind the routine hustle.

### Where the Waters Meet
Mukutmanipur is famous for hosting the second largest earthen dam in the world. Standing along the 11-kilometer stretch of the dam, with the vast expanse of the Kangsabati reservoir on one side and rolling hills on the horizon, gives an indescribable sense of freedom.

The water reflects the changing hues of the afternoon sky, turning from cobalt blue to molten gold as dusk creeps in. Local fishermen gently guide their small wooden canoes across the calm ripples, adding an almost cinematic stillness to the landscape.

### Tips for Travelers
1. **Best Time to Visit:** October to March offers crisp, pleasant weather with clear skies.
2. **Photography Tip:** Arrive at the dam around 4:30 PM to capture golden-hour silhouettes.
3. **Local Flavor:** Don't forget to savor the freshly caught fish curry prepared at small earthen stalls nearby.

Every time I turn off the ignition and sit by the water's edge, I am reminded of why I started this blog: to share the raw beauty of our own homeland that often goes unnoticed in fast-paced city lives.`,
    coverImage: travelBankuraImg,
    readTime: '4 min read',
    publishedAt: '2026-10-08',
    tags: ['Bankura', 'TravelStory', 'MotorcycleTour', 'Mukutmanipur', 'BengalWanderer'],
    isPinned: true,
    likes: 42,
    views: 318,
    comments: [
      {
        id: 'c-1',
        author: 'Subhajit Roy',
        content: 'Loved the photography and the description of the Mukutmanipur route! Proud to see Bankura represented so beautifully.',
        createdAt: '2026-10-08 19:40',
      },
      {
        id: 'c-2',
        author: 'Priya Mukherjee',
        content: 'The sunset view is breathtaking. Looking forward to your next travel guide!',
        createdAt: '2026-10-09 08:15',
      }
    ],
    featured: true,
  },
  {
    id: 'post-2',
    title: 'Essential Digital Tools & Productivity Workflow for Modern Content Creators',
    slug: 'essential-digital-tools-workflow-content-creators',
    category: 'Technology',
    excerpt: 'A peek into the apps, gear, and minimalist automation workflows that keep my blogging consistent without burning out.',
    content: `When people ask me how I balance writing, photography, social media, and everyday life, my answer is simple: systems over motivation. 

Technology shouldn't complicate our creative process; it should clear the friction between an idea in your head and a published story on screen.

### 1. Distraction-Free Writing
Before touching formatting or thumbnails, raw ideas need a clean canvas. I prefer minimal Markdown editors that allow fast typing without toolbars getting in the way. Focus on flow first; edit and polish later.

### 2. Fast Media Optimization
Heavy images kill website performance. I run all photography through modern WebP compressors and high-res batch resizing before publishing. This guarantees quick load times even on mobile connections across rural and suburban areas.

### 3. Lightweight Digital Organization
- **Notion or Obsidian:** For keeping track of article drafts, travel route checklists, and gadget reviews.
- **Canva & Lightroom Mobile:** For swift color correction and social banner adjustments on the go.
- **Cloud Backups:** Never trust a single SD card. As soon as a ride concludes, footage and RAW captures are cloned immediately.

Mastering a few reliable tools beats chasing every trending novelty. Choose tools that disappear into your workflow and let your message take center stage.`,
    coverImage: techSetupImg,
    readTime: '5 min read',
    publishedAt: '2026-10-06',
    tags: ['Technology', 'Productivity', 'CreatorTools', 'Workflow', 'BloggingTech'],
    isPinned: false,
    likes: 29,
    views: 245,
    comments: [
      {
        id: 'c-3',
        author: 'Arindam Ghosh',
        content: 'Great breakdown Kousik! The advice on media compression is so true for web speed.',
        createdAt: '2026-10-07 11:20',
      }
    ],
    featured: false,
  },
  {
    id: 'post-3',
    title: 'Morning Rituals, Warm Coffee, and the Art of Consistent Journaling',
    slug: 'morning-rituals-coffee-art-of-journaling',
    category: 'Lifestyle',
    excerpt: 'How waking up thirty minutes before the world stirs and pouring coffee over a notebook transformed my clarity and focus.',
    content: `There is something sacred about the early morning hour. The world is quiet, notifications haven't yet hijacked your attention, and the day is a blank slate.

For the past three years, my day has begun with the same two constants: a freshly brewed mug of warm black coffee and a physical paper notebook.

### The Pen and Paper Magic
In an age saturated with digital screens, holding an ink pen to physical paper creates an intimate cognitive pause. Writing by hand forces you to slow down your thoughts. You cannot hit backspace at lightspeed; you have to sit with what you feel.

I jot down three simple prompts each morning:
- **One gratitude:** Something small from yesterday I didn't appreciate enough.
- **One priority:** If only one meaningful task gets done today, what must it be?
- **One freeform reflection:** A thought, a snippet of a song, or an idea for a new blog post.

### Cultivating Mindful Habits
Consistency doesn't require drastic 5 AM alarms or grueling regimes. It simply requires protecting twenty quiet minutes where nothing demands anything from you. That calm clarity fuels everything I create thereafter.`,
    coverImage: lifestyleCoffeeImg,
    readTime: '3 min read',
    publishedAt: '2026-10-03',
    tags: ['Lifestyle', 'Mindfulness', 'MorningRoutine', 'Journaling', 'SlowLiving'],
    isPinned: false,
    likes: 38,
    views: 289,
    comments: [],
    featured: false,
  },
  {
    id: 'post-4',
    title: 'From Simlapal to the Web: Why Every Small Town Story Deserves to Be Told',
    slug: 'from-simlapal-to-web-small-town-stories',
    category: 'Personal Stories',
    excerpt: 'Growing up in Bankura taught me that profound stories do not only belong to megacities. Here is why I started sharing my journey.',
    content: `When I first started writing online, I often wondered if anyone outside my district would care about the life, thoughts, and travels of someone from Simlapal, Bankura.

We often grow up looking at high-gloss travel documentaries and bustling city vlogs, thinking that meaning only exists in skyscrapers and famous landmarks. But over time, I discovered something liberating: authenticity has no postal code.

### The Quiet Strength of Our Roots
Living here taught me patience, a deep connection to seasonal rhythms, and the joy of genuine human interactions. When an elder at the village tea stall shares folklore, or when friends gather beneath the banyan tree at sunset, there is an innate poetry there that deserves to be written down.

### Connecting Across Distance
Blogging became my bridge. Through this website and my social channels, I began hearing from readers in Kolkata, Delhi, Bangalore, and even abroad — people who either reminisce about their ancestral Bengal roots or who relate to the universal desire to learn, explore, and create something genuine.

As my favorite saying goes: *“Every journey begins with a single step.”* You don’t need the most expensive gear or a bustling metropolis to start creating. You just need your eyes open, an honest voice, and the courage to hit publish.`,
    coverImage: kousikPortraitImg,
    readTime: '6 min read',
    publishedAt: '2026-09-28',
    tags: ['PersonalStories', 'Simlapal', 'BankuraDiaries', 'LifeLessons', 'Inspiration'],
    isPinned: false,
    likes: 56,
    views: 412,
    comments: [
      {
        id: 'c-4',
        author: 'Ananya Sen',
        content: 'This touched my heart so deeply. Real and grounded writing is so rare nowadays. Keep shining Kousik!',
        createdAt: '2026-09-29 14:10',
      }
    ],
    featured: true,
  },
];

const STORAGE_KEY = 'kousik_blog_posts_v1';

export function getStoredPosts(): BlogPost[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(initialBlogPosts));
      return initialBlogPosts;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return parsed;
    }
  } catch (err) {
    console.error('Error loading stored posts:', err);
  }
  return initialBlogPosts;
}

export function saveStoredPosts(posts: BlogPost[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(posts));
  } catch (err) {
    console.error('Error saving posts to localStorage:', err);
  }
}
